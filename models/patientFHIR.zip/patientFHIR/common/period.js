const period = {
    start:  Date,
    end:    Date
};

module.exports = {period};