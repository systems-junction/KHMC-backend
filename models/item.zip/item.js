const mongoose = require('mongoose');

const itemSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please add name']
    },
    scientificName: {
        type: String,
    },
    tradeName: {
        type: String,
    },
    temprature: {
        type: String,
    },
    humidity: {
        type: String,
    },
    lightSensitive:{
        type: String,
        enum: ['false', 'true']
    },
    resuableItem:{
        type: String,
        enum: ['false', 'true']
    },
    storageCondition:{
        type: String
    },
    description: {
        type: String,
        required: [true, 'Please add description']
    },
    
    cls: {
        type: String
    },
    subClass: {
        type: String
    },
    grandSubClass: {
        type: String
    },
    itemCode: {
        type: String,
        required: [true, 'Please add bar code'],
    },
    receiptUnit: {
        type: mongoose.Schema.ObjectId,
        ref: 'functionalUnit',
        required: [true, 'Please select Receipt Unit']
    },
    receiptUnitCost: {
        type: String,
        required: [true, 'Please select Receipt Unit Cost']
    },
    expiration:{
        type: Date
    },
    issueUnit: {
        type: mongoose.Schema.ObjectId,
        ref: 'functionalUnit',
        required: [true, 'Please select Issue Unit']
    },
    issueUnitCost: {
        type: String,
        required: [true, 'Please Insert Issue Unit Cost']
    },
    tax:{
        type: Number,
        required: [true, 'Please Insert Tax']  
    },
    vendorId: {
        type: mongoose.Schema.ObjectId,
        ref: 'Vendor',
        required: [true, 'Please select Vendor']
    },
    purchasePrice: {
        type: String,
        required: [true, 'Please add purchase price'],
    },
    minimumLevel: {
        type: String
    },
    maximumLevel: {
        type: String
    },
    reorderLevel: {
        type: String
    }, 
    comments: {
        type: String
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Item', itemSchema);
